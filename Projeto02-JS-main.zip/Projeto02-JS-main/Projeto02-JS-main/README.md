# Projeto02-JS
Site que faz pesquisa de pokemons e mostra seu número, nome e gif animado, por meio do consumo de uma API

Tecnologias usadas: HTML, CSS e JavaScript
